function start() { // On page load
	game = {} ;
	game.options = new Options(true) ;
	config_init('keyword', 'keyword')
}
