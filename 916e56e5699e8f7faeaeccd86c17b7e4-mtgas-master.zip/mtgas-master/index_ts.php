  <div id="teamspeak" class="section">
   <h1>Teamspeak</h1>
   <a href="ts3server://213.246.55.19?port=9987">Connect to server : ts.mogg.fr (port 9987)</a>
   <iframe src="http://ts.mogg.fr/tsviewpub.php?skey=0&sid=1&showicons=right&bgcolor=ffffff&fontcolor=000000" style="width:100%" frameborder="0">Your Browser will not show Iframes</iframe>
   <a href="http://www.teamspeak.com/?page=downloads">Download teamspeak client</a>
  </div>

